ui.py is inspired by [https://github.com/eagleflo/goban].
